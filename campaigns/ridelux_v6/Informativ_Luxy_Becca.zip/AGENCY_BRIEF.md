# INFORMATIV × LUXY Ride — Agency Campaign Brief
## For: Zero Gravity Marketing (Becca Matyasovsky)
## Date: April 14, 2026

---

## WHAT THIS IS

INFORMATIV has developed a **psycholinguistic advertising intelligence system** that matches ad creative to the psychological context of the reader. We've analyzed LUXY Ride's actual customer base — corporate travel arrangers, travel managers, event planners, legal ops, pharma compliance, and financial dealmakers — and identified **6 launch audiences** (with 5 more in Phase 2) with **6 distinct creative treatments** for launch.

This brief provides everything you need to run a year-long campaign in StackAdapt for LUXY Ride at approximately **$24,000/week ($96K/month), concentrated for maximum learning velocity**.

**Key insight:** LUXY Ride is a **corporate black car service** integrated with Concur, TripActions, CWT, Amex GBT, CTM, and FCM. The customer is never "a person who likes luxury." The customer is an EA booking for an executive, a travel manager evaluating vendors, an event planner coordinating group arrivals. Every domain, every creative, and every targeting decision in this brief reflects that reality.

---

## HOW THIS WORKS

### You Control (Agency)
- StackAdapt campaign setup, management, and optimization
- Creative production (images — we provide copy and art direction)
- Bid strategy, pacing, and budget allocation
- Day-to-day campaign optimization

### INFORMATIV Provides
- **Campaign strategy**: 6 launch audiences + 5 Phase 2, creative copy, domain targeting
- **Behavioral intelligence**: Telemetry script on luxyride.com capturing post-click behavior
- **Every-other-day optimization**: Specific StackAdapt changes recommended based on observed data
- **Domain targeting**: Per-audience whitelists verified at the article level

### LUXY Ride Provides
- Google Tag Manager access (one tag to install)

---

## THE AUDIENCES

### Phase 1 — Launch (6 audiences, 18 campaigns)

Budget percentages below are INFORMATIV's starting recommendation. Final allocation is at agency discretion based on StackAdapt inventory and early performance.

| # | Audience | Suggested % | Campaigns | Archetype (internal) |
|---|---|---|---|---|
| 1 | Corporate Travel Arrangers (EAs) | 28% | EA-T1, EA-T2, EA-T3 | reliable_cooperator |
| 2 | Corporate Travel Managers | 25% | TM-T1, TM-T2, TM-T3 | dependable_loyalist |
| 3 | Home Market (CT/NYC) | 18% | HM-T1, HM-T2, HM-T3 | dependable_loyalist (geo-targeted) |
| 4 | Event / Meeting / Incentive Planners | 12% | EV-T1, EV-T2, EV-T3 | prevention_planner |
| 5 | Legal Vertical (BigLaw) | 10% | LG-T1, LG-T2, LG-T3 | careful_truster |
| 6 | Life Sciences / Pharma | 7% | LS-T1, LS-T2, LS-T3 | careful_truster |

**Note on HM (Home Market):** HM shares the same psycholinguistic archetype as TM (`dependable_loyalist`) but uses a geo-specific domain whitelist (CT/NYC publications). That's why there's a separate `stackadapt_whitelist_home_market.csv` alongside `stackadapt_whitelist_dependable_loyalist.csv`. Use HM whitelist for HM campaigns, dependable_loyalist whitelist for TM campaigns.

### Phase 2 — Expansion (weeks 5+, activated based on Phase 1 signal)

Phase 2 campaigns are held back until Phase 1 has produced enough data to inform targeting. INFORMATIV will advise when to activate.

| # | Audience | Campaigns | Archetype (internal) |
|---|---|---|---|
| 7 | Financial Dealmakers | FI-T1, FI-T2, FI-T3 | dependable_loyalist |
| 8 | Supply Partners (hotel/venue referrals) | SP-T1, SP-T2, SP-T3 | dependable_loyalist |
| 9 | Private Aviation (FBO/jet charter) | PA-T1, PA-T2, PA-T3 | trusting_loyalist |
| 10 | CFO / T&E Owners | CF-T1, CF-T2, CF-T3 | careful_truster |
| 11 | Hotel B2B / Group Sales | HT-T1, HT-T2, HT-T3 | dependable_loyalist |

---

## TAG INSTALLATION

### Tag A: StackAdapt Universal Pixel (All Pages)
```html
<script>
  !function(s,a,e,v,n,t,z){if(s.saq)return;n=s.saq=function(){
  n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!s._saq)s._saq=n;n.push=n;n.loaded=!0;n.version='1.0';n.queue=[];
  t=a.createElement(e);t.async=!0;t.src=v;z=a.getElementsByTagName(e)[0];
  z.parentNode.insertBefore(t,z)}(window,document,'script',
  'https://tags.srv.stackadapt.com/events.js');
  saq('ts', 'YOUR_UNIVERSAL_PIXEL_ID');
</script>
```

### Tag B: INFORMATIV Behavioral Intelligence (All Pages)
```html
<script src="https://focused-encouragement-production.up.railway.app/static/telemetry/informativ.js"
        data-endpoint="https://focused-encouragement-production.up.railway.app/api/v1/signals/session"
        defer></script>
```

---

## CONVERSION EVENTS

| # | Name (exact) | Method | Rule | Attribution | Primary |
|---|---|---|---|---|---|
| 1 | `luxy_site_visit` | Page Load | URL contains `luxyride.com` | 30 days | No |
| 2 | `luxy_booking_page` | Page Load | URL contains `/programs/book` | 14 days | No |
| 3 | `luxy_booking_start` | Page Load | Booking trigger | 7 days | No |
| 4 | `luxy_booking_complete` | Custom Event | Confirmation page | 7 days | **YES** |
| 5 | `luxy_corporate_signup` | Page Load | Corporate Program signup | 14 days | No |

---

## AUDIENCES

| # | Name | Type | Rule | Lookback |
|---|---|---|---|---|
| 1 | `luxy_all_visitors` | Retargeting | URL contains luxyride.com | 30 days |
| 2 | `luxy_booking_visitors` | Retargeting | URL contains `/programs/book` | 14 days |
| 3 | `luxy_high_intent` | Retargeting | Visit frequency >= 3 | 14 days |
| 4 | `luxy_converted_exclude` | Exclusion | Event: luxy_booking_complete | 90 days |
| 5 | `luxy_booking_abandoned` | Retargeting | booking_start AND NOT complete | 7 days |

**CRITICAL**: Apply `luxy_converted_exclude` as exclusion to ALL 18 campaigns.

---

## DOMAIN LISTS

| Audience | Whitelist File |
|---|---|
| Travel Arrangers (EAs) | `stackadapt_whitelist_reliable_cooperator.csv` |
| Travel Managers | `stackadapt_whitelist_dependable_loyalist.csv` |
| Home Market (CT/NYC) | `stackadapt_whitelist_home_market.csv` |
| Event Planners | `stackadapt_whitelist_prevention_planner.csv` |
| Legal Vertical | `stackadapt_whitelist_careful_truster.csv` |
| Life Sciences | `stackadapt_whitelist_careful_truster.csv` (shared with Legal) |

**Shared blacklist**: `stackadapt_blacklist_upload.csv` → ALL campaigns.

### IMPORTANT: Inventory Verification Before Launch

**Before setting any campaign to ACTIVE**, please verify domain-level inventory availability in StackAdapt's forecasting tool for each whitelist. Many of these domains are niche B2B trade publications that may have limited programmatic inventory.

**For each audience whitelist:**
1. Upload the CSV to StackAdapt as a Site Inclusion List
2. Run a forecast/estimate for that campaign group at the assigned daily budget
3. Check estimated daily impressions

**If estimated impressions are below the daily budget target** (meaning StackAdapt can't spend the allocated budget on those domains alone), add **contextual keyword targeting** as a supplement:

| Audience | Fallback Keyword Targets |
|---|---|
| Travel Arrangers | "corporate travel management" + "executive assistant travel" + "ground transportation booking" |
| Travel Managers | "corporate travel program" + "travel management company" + "preferred vendor ground transport" |
| Home Market | Keep whitelist only — regional pubs should have sufficient inventory |
| Event Planners | "event transportation" + "meeting logistics" + "group ground transport" + "conference planning" |
| Legal | "law firm travel" + "legal travel management" + "BigLaw" + "litigation travel" |
| Life Sciences | "pharma travel compliance" + "HCP travel" + "life sciences travel management" |

**The keyword targeting supplements the whitelist — it does NOT replace it.** StackAdapt should target impressions that match EITHER the whitelist domains OR the keyword context. This ensures we spend the full budget while maintaining targeting relevance.

**Report back to INFORMATIV** after running forecasts: which audiences have sufficient whitelist inventory and which needed keyword supplementation. This affects our optimization strategy.

### Domain Targeting Notes for Specific Audiences

**Event Planners** — this whitelist has only 4 domains. Keyword supplementation is almost certainly needed. Target keywords: "event transportation logistics", "conference shuttle service", "group airport transfer", "meeting planner ground transport". StackAdapt's contextual targeting should find relevant inventory across event industry content.

**Legal + Life Sciences** — these share the same whitelist. If they compete for inventory and one audience consistently outbids the other, consider splitting into separate whitelists with distinct domains. Alternatively, supplement with audience-specific keywords as above.

---

## CLICK URL (ALL campaigns)

```
https://luxyride.com/?sapid={SA_POSTBACK_ID}&cid={CAMPAIGN_ID}&crid={CREATIVE_ID}&domain={DOMAIN}&device={DEVICE_TYPE}&ts={TIMESTAMP}
```

---

## CAMPAIGN DETAILS

### 1. Corporate Travel Arrangers — EA (22%, $960/day)

| Campaign | Headline | Body | CTA | $/day | Goal |
|---|---|---|---|---|---|
| EA-T1 | "Your executive's next trip, booked in 30 seconds" | LUXY integrates with Concur, TripActions, and every major TMC. Your travelers get professional chauffeurs. You get one-click booking and real-time trip tracking. | See how it works | $480 | Clicks |
| EA-T2 | "The ground transport your travelers actually deserve" | Not all car services are equal. Company-employed drivers. Background checks. Flight monitoring. Your executive's preferences saved from the first ride. | Compare services | $320 | Clicks |
| EA-T3 | "Your booking hub for every airport, every city" | One platform, 100+ cities, integrated with your travel management system. Book for your travelers in seconds. Concierge Dashboard built for travel arrangers. | Start booking | $160 | Conversions |

**Frequency**: 2/day, 7/week | **Dayparting**: +20% 8-10am, +15% 1-3pm

---

### 2. Corporate Travel Managers (20%, $857/day)

| Campaign | Headline | Body | CTA | $/day | Goal |
|---|---|---|---|---|---|
| TM-T1 | "43% of companies don't have a chauffeured contract. Yours?" | BTN 2026 survey: service consistency jumped 0.47 points for preferred partners. LUXY serves 400+ companies through Concur, TripActions, CWT, Amex GBT, CTM, FCM. | See the data | $428 | Clicks |
| TM-T2 | "Company-employed chauffeurs. Scored 4.43/5 in BTN survey." | The highest driver quality metric in the BTN 2026 ground transportation survey. Background checks, GPS tracking, 24/7 dispatch. The compliance your program requires. | Request vendor packet | $286 | Clicks |
| TM-T3 | "Add LUXY to your preferred vendor list" | Corporate rates. Policy-compliant booking. Real-time trip-level spend data. 400+ companies onboarded. No minimum commitment. | Start corporate program | $143 | Conversions |

**Frequency**: 2/day, 7/week | **Dayparting**: +20% 9-11am, +15% 2-4pm

---

### 3. Home Market — CT/NYC (15%, $617/day)

| Campaign | Headline | Body | CTA | $/day | Goal |
|---|---|---|---|---|---|
| HM-T1 | "The Connecticut-based car service trusted by 400+ companies" | Stamford to JFK. Greenwich to LaGuardia. New Haven to Newark. Chauffeurs who know your routes, your buildings, your airports. | See local coverage | $309 | Clicks |
| HM-T2 | "Your NYC ground transport, handled" | Midtown to Teterboro in 40 minutes. Wall Street to JFK, door to door. 99.7% on-time across the tri-state. | Check your route | $206 | Clicks |
| HM-T3 | "Your neighbors already ride with us" | 400+ companies in the CT/NYC corridor trust LUXY. Corporate rates, Concur integration, chauffeurs who know the tri-state. | Book your first ride | $103 | Conversions |

**Frequency**: 2/day, 8/week | **Dayparting**: +25% 7-9am, +20% 5-7pm

---

### 4. Event Planners (12%, $411/day)

| Campaign | Headline | Body | CTA | $/day | Goal |
|---|---|---|---|---|---|
| EV-T1 | "Your 200-person airport arrival, handled" | Multi-vehicle coordination across every LUXY city. Backup operators at every location. Real-time manifest tracking. | See group capabilities | $206 | Clicks |
| EV-T2 | "Zero transportation failures at your next event" | Flight monitoring for every attendee. Automatic delay adjustment. Contingency vehicles pre-positioned. | Plan your event | $114 | Clicks |
| EV-T3 | "The event planner's ground transport partner" | Conferences. Incentive trips. Galas. Board retreats. One booking hub, every city, every vehicle class. | Get a group quote | $58 | Conversions |

**Frequency**: 2/day, 7/week | **Dayparting**: +20% 9am-12pm

---

### 5. Legal Vertical (10%, $343/day)

| Campaign | Headline | Body | CTA | $/day | Goal |
|---|---|---|---|---|---|
| LG-T1 | "On time, every time. Your billable hour is non-negotiable." | A partner billing $1,200/hr cannot afford a 45-minute rideshare delay. Company-employed chauffeurs, flight monitoring, guaranteed pickup. | Learn more | $171 | Clicks |
| LG-T2 | "SOC 2 data handling. Vetted for BigLaw." | Background-checked drivers. GPS tracking. Disbursement-ready receipts. Duty of care for associates in unfamiliar cities. | See credentials | $114 | Clicks |
| LG-T3 | "Depositions. Court appearances. Client visits. Covered." | Courthouse to hotel. Office to airport. 100+ cities, integrated with Amex GBT Legal. | Set up firm account | $57 | Conversions |

**Frequency**: 2/day, 6/week | **Dayparting**: +20% 7-9am, +15% 5-8pm

---

### 6. Life Sciences / Pharma (7%, $240/day)

| Campaign | Headline | Body | CTA | $/day | Goal |
|---|---|---|---|---|---|
| LS-T1 | "Ground transport built for life sciences compliance" | Every HCP ride creates reporting obligations. LUXY captures booker, passenger, addresses, duration, amount — the data your compliance team needs, in every ride receipt. | See compliance features | $120 | Clicks |
| LS-T2 | "Fewer than half of pharma programs meet a global standard" | BCD benchmarking of 15 global life sciences travel policies found fewer than half meet a consistent standard. LUXY: one platform, one standard, every ride documented. | Request compliance demo | $80 | Clicks |
| LS-T3 | "Ground transport designed for regulated industries" | Detailed ride documentation. Passenger records. Event association. Integrated with BCD, Amex GBT, CWT. Purpose-built for industries where every ride is auditable. | Start pilot program | $40 | Conversions |

**Frequency**: 2/day, 6/week | **Dayparting**: +20% 9-11am

---

## IMAGE ART DIRECTION

| Audience | Visual Style | Palette |
|---|---|---|
| Travel Arrangers | Clean booking interface, EA at desk, laptop | Navy, white, teal |
| Travel Managers | Data dashboard, compliance badges, professional | Slate, white, green |
| Home Market | NYC skyline, CT suburbs, recognizable landmarks | Warm navy, gold |
| Event Planners | Group arrivals, multiple vehicles, venue exterior | Black, emerald |
| Legal | Courthouse, downtown professional, boardroom | Dark navy, silver |
| Life Sciences | Lab-to-airport, compliance documents | White, blue, trust green |

**Sizes**: 1200x627 (primary), 600x600 (square), 800x600 (alternate). JPG/PNG under 2MB.

---

## OPTIMIZATION CADENCE

**Every other day** — INFORMATIV delivers specific StackAdapt actions:
- Which audiences/domains are converting (with data)
- Budget shift recommendations (with dollar amounts)
- Creative refresh signals
- New domain recommendations
- User suppression list updates

**Agency implements** recommended changes within 24 hours.

### Data We Need From You (Ongoing)

As the campaign runs, please provide the following to INFORMATIV at each optimization cycle. This feeds our intelligence system and improves targeting accuracy:

1. **Conversion URL patterns** — After the first conversions come in, share the exact URLs of the booking confirmation page(s) that fire the `luxy_booking_complete` event. Example: `luxyride.com/booking/confirmed` or `luxyride.com/thank-you`. We need this to calibrate our server-side conversion tracking.

2. **Campaign performance export** — Every other day, export a campaign-level CSV from StackAdapt: impressions, clicks, conversions, spend, CTR, conversion rate, by campaign. Email to INFORMATIV team.

3. **Domain-level performance** — If StackAdapt provides domain-level reporting, include that in the export. This tells us which specific domains are producing clicks and conversions, which directly improves our targeting model.

4. **Any unexpected patterns** — If you notice one audience overspending or underspending relative to its budget, or if a particular domain is consuming disproportionate budget, flag it. This is valuable signal.

5. **Conversion details when available** — As bookings come in, share what you can about the conversion: which campaign, which creative, which domain the user was on when they clicked. This is the gold data that trains the system.

### What INFORMATIV Sends You (Every Other Day)

A specific action report with:
- **Budget shifts**: "Move $X from [audience] to [audience] because [data]"
- **Domain changes**: "Add [domain] to [audience] whitelist because [data]" or "Remove [domain] because [data]"
- **Creative flags**: "[Campaign] CTR below threshold — consider creative refresh"
- **Suppression updates**: "Add these users to exclusion audience"
- **New test recommendations**: "Test [domain/audience combination] with $X budget"

Every recommendation includes the data behind it. Nothing is a guess.

---

## BEFORE LAUNCH CHECKLIST

### Agency:
- [ ] Both GTM tags installed and published
- [ ] StackAdapt pixel confirmed firing
- [ ] Verify LUXY Ride booking confirmation URL pattern and share with INFORMATIV
- [ ] 6 conversion events created (adjust URL rules if booking confirmation URL differs from default)
- [ ] 5 audiences created
- [ ] `luxy_converted_exclude` on ALL 18 campaigns
- [ ] Per-audience whitelists uploaded
- [ ] **Inventory forecast run for each whitelist** (see Domain Targeting section)
- [ ] **Keyword fallback added where whitelist inventory is insufficient**
- [ ] **Forecast results reported to INFORMATIV** (which audiences needed supplementation)
- [ ] Shared blacklist on all campaigns
- [ ] 6 campaign groups with correct budgets
- [ ] 18 campaigns with correct copy
- [ ] Click URLs include StackAdapt macros
- [ ] Frequency caps set per audience
- [ ] Dayparting set per audience
- [ ] 18 image creatives uploaded
- [ ] All campaigns in DRAFT

### INFORMATIV:
- [ ] Server healthy
- [ ] Telemetry endpoint active
- [ ] CORS configured
- [ ] Intelligence report generator tested

### Joint:
- [ ] Review all 18 campaigns
- [ ] Test clicks verified
- [ ] Optimization cadence confirmed (every 48 hours)
- [ ] Set all to ACTIVE

---

## FILES PROVIDED

| File | Purpose |
|---|---|
| `START_HERE.md` | How to use these files |
| `AGENCY_BRIEF.md` | This document |
| `AGENCY_HANDOFF_COMPLETE.md` | Step-by-step setup |
| `luxy_ride_complete_creatives.json` | 28 campaign specs |
| `stackadapt_whitelist_*.csv` (6 files) | Per-audience whitelists |
| `stackadapt_blacklist_upload.csv` | Shared exclusion list |
| `IMAGE_CREATIVE_BRIEFS.md` | Image specifications |

---

*Every domain hand-researched at the article level. Every creative matched to the reader's professional context. Every audience verified against LUXY Ride's actual customer base.*
